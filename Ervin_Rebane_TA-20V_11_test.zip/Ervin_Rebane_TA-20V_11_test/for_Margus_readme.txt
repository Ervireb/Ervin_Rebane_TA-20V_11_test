Sorry not fully finished yet, mind if i give it back later?
-Ervin Rebane TA-20V 